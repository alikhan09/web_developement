<!DOCTYPE html>
<html>
<head>

	<title>Registeration</title>
    <link rel="stylesheet" href="style.css">
</head>

	

<body>
<form action="information.php" method="POST">
		<input type="text" name="std_name" placeholder="Enter name"> <br>
		<input type="text" name="std_father" placeholder="Enter father name"><br>
		<input type="text" name="r_address" placeholder="Enter address"><br>
        <input type="text" name="p_address" placeholder="Enter parmenent address"><br>
       
        
            <input type="radio" id="BBA" name="course" value="BBA">
            <label for="BBA">BBA</label>

             <input type="radio" id="MBA" name="course" value="MBA">
             <label for="MBA">MBA</label>
        
             <input type="radio" id="BSCS" name="course" value="BSCS">
             <label for="BSCS">BSCS</label> 
        
            <input type="radio" id="MSCS" name="course" value="MSCS">
            <label for="MSCS">MSCS</label><br>  

         <input type="checkbox" id="sport" name="sport[]" value="sport">
           <label for="sport"> Sports Gymnasium</label><br>
            <input type="checkbox" id="unibus" name="sport[]" value="unibus">
            <label for="unibus"> Travel with University Bus Service</label><br>
           <input type="checkbox" id="unihostel" name="sport[]" value="unihostel">
          <label for="unihostel"> University Hostel Accomodation</label><br>
     
		<input type="submit" value="save my data">
	</form>
    <?php
	$conn = new mysqli("localhost","root","", "students");
       $q="select* from std_info";
       $sd = $conn->query($q);
       echo "<table border=2px solid black >";
    echo "<tr>";
    echo "<th>";
    echo "std_id";
    echo "</th>";
    
    echo "<th>";
    echo "std_name";
    echo "</th>";
    
    echo "<th>";
    echo "std_father";
    echo "</th>";
    
    echo "<th>";
    echo "residential";
    echo "</th>";
    echo "<th>";
    echo "permanent";
    echo "</th>";
    echo "<th>";
    echo "course";
    echo "</th>";
    echo "<th>";
    echo "addiitional";
    echo "</th>";
    echo "</tr>";
    
    while($row = $sd->fetch_assoc())
    {
      echo "<tr>";
      echo "<td>";
      echo $row["id"];
      echo "</td>";
      
      echo "<td>";
      echo $row["name"];
      echo "</td>";
      
      echo "<td>";
      echo $row["f_name"];
      echo "</td>";
      
      echo "<td>";
      echo $row["r_address"];
      echo "</td>";
      echo "<td>";
      echo $row["p_address"];
      echo "</td>";
      echo "<td>";
      echo $row["course"];
      echo "</td>";
      echo "<td>";
      echo $row["sport"];
      echo "</td>";
	  

      echo "</tr>";
    }
       echo "</table>";
       ?>
</body>