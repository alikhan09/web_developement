<?php
   $name = $_POST['std_name'];
    $f_name = $_POST['std_father'];
     $residential = $_POST['r_address'];
     $parmanent = $_POST['p_address'];
    $course=$_POST['course'];

       $conn = new mysqli("localhost","root","", "students");
       //insert querry
    $q ="insert into std_info (name,f_name,r_address,p_address,course) values('".$name."','".$f_name."','".$residential."','".$parmanent."','".$course."')";
     
       if ($conn->query($q) === TRUE) {
           echo "data inserted";
         header ("Location:register.php");
         } else {
         echo "Error deleting record: " . $conn->error;
         }
    
?>