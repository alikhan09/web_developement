var cartItems = [];
var itemNames = [];
var totalBill=0;

var itemDetails = {
  "Strong Tea": 10,
  "Kashmiri Tea": 20,
  "Special Tea": 30,
  "Late": 24,
  "Cold brew":17,
  "Irish coffee":21,
  "Nitro coffee": 18,
  "Frappuccino": 50,
  "Chocolate":5,
  "Strawbery":5,
  "Vanila":3,
  "Brownie":8,
};

// Function to toggle visibility of subtypes
function toggleSubtypes(itemIndex) {
  var subtypeList = document.getElementById('subtype-list-' + itemIndex);
  subtypeList.style.display = subtypeList.style.display === 'none' ? 'block' : 'none';
}
// Make an AJAX request to the PHP file
function getdata()
{
var xhr = new XMLHttpRequest();
xhr.open('GET', 'up.php', true);
xhr.onreadystatechange = function() {
    if (xhr.readyState === 4 && xhr.status === 200) {
        // Receive the response and handle the data
        var response = JSON.parse(xhr.responseText);
        console.log(response);

        // Access the data and perform further operations
        for (var i = 0; i < response.length; i++) {
            var item = response[i];
            var price = item.price;
            var name = item.iname;
            var subtype = item.subtype;
            var quantity =item.quantity;
            addToCart1(name,subtype,quantity,price);
            calculateTotalBill();
        }
    }
};
xhr.send();


}

function addToCart1(item,subtype,quan,price ) {
    itemIndex = cartItems.findIndex(cartItem => cartItem.item === item && cartItem.subtype === subtype);
  
    if (itemIndex === -1) {
      cartItems.push({ item: item,subtype: subtype, quantity: quan,price:price });
      updateCart();
    } else {
      cartItems[itemIndex].quantity++;
    }
    if(itemIndex===-1)
    {
       itemIndex = cartItems.findIndex(cartItem => cartItem.item === item && cartItem.subtype === subtype);
  
    }
    if(subtype==='Strong Tea'){
      document.getElementById("count1").innerHTML = cartItems[itemIndex].quantity;
      document.getElementById("c1").innerHTML = cartItems[itemIndex].quantity*itemDetails['Strong Tea'];
    }
    if(subtype==='Kashmiri Tea')
    {
      document.getElementById("count2").innerHTML = cartItems[itemIndex].quantity;
      document.getElementById("c2").innerHTML = cartItems[itemIndex].quantity*itemDetails['Kashmiri Tea'];
  
    }
    if(subtype==='Special Tea')
    {
      document.getElementById("count3").innerHTML = cartItems[itemIndex].quantity;
      document.getElementById("c3").innerHTML = cartItems[itemIndex].quantity*itemDetails['Special Tea'];
  
    }
    if(subtype==='Late')
    {
      document.getElementById("count4").innerHTML = cartItems[itemIndex].quantity;
      document.getElementById("c4").innerHTML = cartItems[itemIndex].quantity*itemDetails['Late'];
  
    }
    if(subtype==='Cold brew')
    {
      document.getElementById("count5").innerHTML = cartItems[itemIndex].quantity;
      document.getElementById("c5").innerHTML = cartItems[itemIndex].quantity*itemDetails['Cold brew'];
  
  
    }
    if(subtype==='Irish coffee')
    {
      document.getElementById("count6").innerHTML = cartItems[itemIndex].quantity;
      document.getElementById("c6").innerHTML = cartItems[itemIndex].quantity*itemDetails['Irish coffee'];
  
  
    }
    if(subtype==='Frappuccino')
    {
      document.getElementById("count8").innerHTML = cartItems[itemIndex].quantity;
      document.getElementById("c8").innerHTML = cartItems[itemIndex].quantity*itemDetails['Frappuccino'];
    }
    if(subtype==='Nitro coffee')
    {
      document.getElementById("count7").innerHTML = cartItems[itemIndex].quantity;
      document.getElementById("c7").innerHTML = cartItems[itemIndex].quantity*itemDetails['Nitro coffee'];
    }
    if(subtype==='Chocolate')
    {
      document.getElementById("count9").innerHTML = cartItems[itemIndex].quantity;
      document.getElementById("c9").innerHTML = cartItems[itemIndex].quantity*itemDetails['Chocolate'];
    }
    if(subtype==='Strawbery')
    {
      document.getElementById("count10").innerHTML = cartItems[itemIndex].quantity;
      document.getElementById("c10").innerHTML = cartItems[itemIndex].quantity*itemDetails['Strawbery'];
    }
    if(subtype==='Vanila')
    {
      document.getElementById("count11").innerHTML = cartItems[itemIndex].quantity;
      document.getElementById("c11").innerHTML = cartItems[itemIndex].quantity*itemDetails['Vanila'];
    }
    if(subtype==='Brownie')
    {
      document.getElementById("count12").innerHTML = cartItems[itemIndex].quantity;
      document.getElementById("c12").innerHTML = cartItems[itemIndex].quantity*itemDetails['Brownie'];
    }
  updateCart();
  }

  function addToCart(item, subtype) {
    var itemIndex = cartItems.findIndex(cartItem => cartItem.item === item && cartItem.subtype === subtype);
  
    if (itemIndex === -1) {
      cartItems.push({ item: item, subtype: subtype, quantity: 1,price:itemDetails[subtype] });
      updateCart();
    } else {
      cartItems[itemIndex].quantity++;
    }
    if(itemIndex===-1)
    {
       itemIndex = cartItems.findIndex(cartItem => cartItem.item === item && cartItem.subtype === subtype);
  
    }
    if(subtype==='Strong Tea'){
      document.getElementById("count1").innerHTML = cartItems[itemIndex].quantity;
      document.getElementById("c1").innerHTML = cartItems[itemIndex].quantity*itemDetails['Strong Tea'];
    }
    if(subtype==='Kashmiri Tea')
    {
      document.getElementById("count2").innerHTML = cartItems[itemIndex].quantity;
      document.getElementById("c2").innerHTML = cartItems[itemIndex].quantity*itemDetails['Kashmiri Tea'];
  
    }
    if(subtype==='Special Tea')
    {
      document.getElementById("count3").innerHTML = cartItems[itemIndex].quantity;
      document.getElementById("c3").innerHTML = cartItems[itemIndex].quantity*itemDetails['Special Tea'];
  
    }
    if(subtype==='Late')
    {
      document.getElementById("count4").innerHTML = cartItems[itemIndex].quantity;
      document.getElementById("c4").innerHTML = cartItems[itemIndex].quantity*itemDetails['Late'];
  
    }
    if(subtype==='Cold brew')
    {
      document.getElementById("count5").innerHTML = cartItems[itemIndex].quantity;
      document.getElementById("c5").innerHTML = cartItems[itemIndex].quantity*itemDetails['Cold brew'];
  
  
    }
    if(subtype==='Irish coffee')
    {
      document.getElementById("count6").innerHTML = cartItems[itemIndex].quantity;
      document.getElementById("c6").innerHTML = cartItems[itemIndex].quantity*itemDetails['Irish coffee'];
  
  
    }
    if(subtype==='Frappuccino')
    {
      document.getElementById("count8").innerHTML = cartItems[itemIndex].quantity;
      document.getElementById("c8").innerHTML = cartItems[itemIndex].quantity*itemDetails['Frappuccino'];
    }
    if(subtype==='Nitro coffee')
    {
      document.getElementById("count7").innerHTML = cartItems[itemIndex].quantity;
      document.getElementById("c7").innerHTML = cartItems[itemIndex].quantity*itemDetails['Nitro coffee'];
    }
    if(subtype==='Chocolate')
    {
      document.getElementById("count9").innerHTML = cartItems[itemIndex].quantity;
      document.getElementById("c9").innerHTML = cartItems[itemIndex].quantity*itemDetails['Chocolate'];
    }
    if(subtype==='Strawbery')
    {
      document.getElementById("count10").innerHTML = cartItems[itemIndex].quantity;
      document.getElementById("c10").innerHTML = cartItems[itemIndex].quantity*itemDetails['Strawbery'];
    }
    if(subtype==='Vanila')
    {
      document.getElementById("count11").innerHTML = cartItems[itemIndex].quantity;
      document.getElementById("c11").innerHTML = cartItems[itemIndex].quantity*itemDetails['Vanila'];
    }
    if(subtype==='Brownie')
    {
      document.getElementById("count12").innerHTML = cartItems[itemIndex].quantity;
      document.getElementById("c12").innerHTML = cartItems[itemIndex].quantity*itemDetails['Brownie'];
    }
    savedata(cartItems,itemIndex);
  updateCart();
  }
  // Function to calculate the total bill
function calculateTotalBill() {
    var total = 0;
    for (var i = 0; i < cartItems.length; i++) {
      var item = cartItems[i];
      var qua = cartItems[i].quantity;
      total = total+(itemDetails[item.subtype]*qua);
    }
    return total;
  }
  
   // Function to display the cart
   function updateCart() {
    var cartContent = "Cart Items:\n";
    for (var i = 0; i < cartItems.length; i++) {
      if(cartContent)
      cartContent += " " + cartItems[i].item + "- " + cartItems[i].subtype +" " + cartItems[i].quantity+"\n";
    }
    document.getElementById("cartItems").innerText = cartContent;
    document.getElementById("totalBill").innerText = "Total Bill: $" + calculateTotalBill();
  }
  
  // Function to send subtype count and name to the PHP file for saving
  function savedata(cartItems,itemIndex) {
    var send_obj = cartItems[itemIndex]
    var xhr = new XMLHttpRequest();
    var url = "save.php";
    xhr.open("POST", url, true);
    xhr.setRequestHeader("Content-Type", "application/json");
    var jsonData = JSON.stringify(send_obj);
    xhr.send(jsonData);
  }