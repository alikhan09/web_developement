<?php
// Establish a database connection
$connection = mysqli_connect('localhost', 'root', '', 'order');

// Check if the connection was successful
if (!$connection) {
    die('Database connection failed: ' . mysqli_connect_error());
}

// Retrieve the data from the database
$sql = "SELECT * FROM item where quantity > 0";
$result = mysqli_query($connection, $sql);

// Fetch the data and organize it into an array
$data = array();
while ($row = mysqli_fetch_assoc($result)) {
    $data[] = $row;
}

// Encode the data as JSON
$jsonData = json_encode($data);

// Send the encoded data as the response
header('Content-Type: application/json');
echo $jsonData;

// Close the database connection
mysqli_close($connection);
?>
