<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="style1.css">
    <style>
        body {
      background-image: url('gloria.jpg');
      background-repeat: no-repeat;
      background-size: cover;
    }
    </style>
</head>
<body>
    <h1 class="con1"> Enter Data to Login </h1>
    <div class="con">
        <form action="search.php" method="POST">
        <input class="in" type="email" name="email" placeholder="Enter email"><br>
        <input class="in" type="password" name="pass" placeholder="Enter Password"><br>
        <input class="lgn" type="submit" value="Login">
        </form>
    </div>
  

</body>
</html>