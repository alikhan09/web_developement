<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>login page</title>
    <style>
        body {
      background-image: url('gloria.jpg');
      background-repeat: no-repeat;
      background-size: cover;
    }
    </style>
    <link rel="stylesheet" href="style1.css">
</head>
<body>
    <h1 class="con1"> Enter Data to sign up </h1>
    <div class="con">
        <form action="signup.php" method="POST">
         <label for="">User name : </label>
		<input type="text" name="username" placeholder="Enter username" class="in"> <br>
        <label for="">Email     :      </label>
		<input type="email" name="email" placeholder="Enter email" class="in"><br>
        <label for="">Password : </label>
		<input type="password" name="pass" placeholder="Enter Password" class="in"><br>
		<input type="submit" value="SignUp" class="lgn">
	</form>
    </div>

    <h1 class="con1">Click here to login </h1>
    <div class="con">
    <a href="login.php" class="lgn"> Login <br></a>
    </div>

   
</body>
</html>