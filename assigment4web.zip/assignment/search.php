<?php
$email = $_POST['email'];
$pass = $_POST['pass'];
$conn= new mysqli("localhost","root","","loginpage");

$q = "select username from user_info where email like '".$email."' and password like '".$pass."'";
$sd =$conn->query($q);
$row = $sd->fetch_assoc();
if ( $row === NULL) {
  header ("Location:index.php");
} else {
  session_start();
  $_SESSION["username"] = $row["username"];
  header ("Location:menu.php");
   }
?>