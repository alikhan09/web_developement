<?php
$conn= new mysqli("localhost","root","","order");

$q = "select * from item where quantity>=1";
$sql="SELECT SUM(price) as total FROM item";
$sd1 = $conn->query($sql);
$sd =$conn->query($q);
echo "<table border=2px solid black >";
echo "<tr>";
echo "<th>";
echo "Item name ";
echo "</th>";


echo "<th>";
echo "Quantity";
echo "</th>";

echo "<th>";
echo "Price";
echo "</th>";

echo "</tr>";
while($row = $sd->fetch_assoc())
    {
      echo "<tr>";
      echo "<td>";
      echo $row["subtype"];
      echo "</td>";
      
      
      echo "<td>";
      echo $row["quantity"];
      echo "</td>";

      echo "<td>";
      echo $row["price"];
      echo "</td>";
      echo "</tr>";
    }
       echo "</table>";
       $row = $sd1->fetch_assoc();
       echo"Total bill : ";
       echo $row["total"];

?>