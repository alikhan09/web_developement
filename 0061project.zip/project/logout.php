<?php
session_destroy();
$conn = new mysqli("localhost","root" , "", "order");
$q="Delete from item";
if ($conn->query($q) === TRUE) {
    echo "Object deleted in the database successfully";
    header ("Location:index.php");
} else {
    echo "Error storing object in the database: " . $conn->error;
}
?>
