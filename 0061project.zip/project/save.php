<?php
// Retrieve the JSON data from the AJAX request
$jsonData = file_get_contents('php://input');

// Decode the JSON data into a PHP associative array
$objectData = json_decode($jsonData, true);

$conn = new mysqli("localhost","root" , "", "order");
// Assuming you have a table called 'objects' with columns 'name', 'age', and 'city'
$iname =$objectData['item'];
$subtype = $objectData['subtype'];
$quantity = $objectData['quantity'];
$price=$objectData['price'];
$price=$price*$quantity;
$q="select * from item where subtype like '$subtype'";
$sd=$conn->query($q);
$row = $sd->fetch_assoc();
if($row["subtype"] != NULL)
{
    if($row["quantity"]>=$quantity)
    {
        $quantity= $quantity+$row["$quantity"];
        $price=$price+$row["$price"];
    }
    $sql = "UPDATE item SET quantity = '$quantity', price = '$price' WHERE subtype like '$subtype'" ;
    if ($conn->query($sql) === TRUE) {
        echo "Object stored in the database successfully";
    } else {
        echo "Error storing object in the database: " . $conn->error;
    }
}
else
{
    $sql = "INSERT INTO item(iname,subtype,quantity,price) VALUES ('$iname','$subtype','$quantity','$price')";

    if ($conn->query($sql) === TRUE) {
        echo "Object stored in the database successfully";
    } else {
        echo "Error storing object in the database: " . $conn->error;
    }
}


$conn->close();
?>