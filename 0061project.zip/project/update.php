<!DOCTYPE html>
<html>
<head>
  <title>Shopping Cart</title>
  <link rel="stylesheet" href="style.css">
  <script src="upd.js"></script>
  
  <style>
    body {
      background-image: url('g1.jpg');
      background-repeat: no-repeat;
      background-size: cover;
       background-position: center ;  
       background-attachment: fixed; 
    }
  </style>
 
</head>
<body>

  <h1 style="text-align: center; font-size: xx-large;">Gloria Coffee</h1>
  <button onclick="getdata()"> Click To update</button>
  
  <div id="menu">
    <div class="container">
      <div style="width: 25%;">

        <h3 class="hover-text" onclick="toggleSubtypes(0)">Tea</h3>
        <ul id="subtype-list-0" class="subtype-list">
          <li>
            <span style="margin-right: 11%; color: azure;"> Strong Tea  </span>
            <button class="lgn" onclick="addToCart('Tea', 'Strong Tea')"> + </button>
          <span style="border: 1px solid black; padding: 0.3%; margin:1%;color: azure;" id="count1">0</span>
            <span style="margin-left:0.5% ;color: azure;" id="c1"> </span> <span style=" color: azure;" >$</span>
          </li>
          <li>
             <span style="margin-right: 5%;color: azure;"> Kashmiri Tea </span>
            
            <button class="lgn" onclick="addToCart('Tea', 'Kashmiri Tea')"> + </button>
          <span style="border: 1px solid black; padding: 0.3%; margin:1%;color: azure;" id="count2">0</span>
            <span style="margin-left:0.5%;color: azure ;" id="c2"> </span> <span style=" color: azure;" >$</span>
          </li>
          <li>
            <span style="margin-right: 9.5%;color: azure;"> Special Tea </span>
            <button class="lgn" onclick="addToCart('Tea', 'Special Tea')"> + </button>
          <span style="border: 1px solid black; padding: 0.3%; margin:1%;color: azure;" id="count3">0</span>
            <span style="margin-left:0.5% ;color: azure;" id="c3"> </span> <span style=" color: azure;" >$</span>
          </li>
        </ul>
      </div>

      <div style="width: 25%;">
      <h3 class="hover-text"onclick="toggleSubtypes(1)"> Hot Coffee</h3>
      <ul id="subtype-list-1" class="subtype-list">
        <li>
         <span style="margin-right: 19%;color: azure;"> Late </span>
          <button class="lgn" onclick="addToCart('Hot Coffee', 'Late')"> + </button>
          <span style="border: 1px solid black; padding: 0.3%; margin:1%;color: azure;" id="count4">0</span>
          <span style="margin-left:0.5% ;" id="c4"> </span> <span>$</span>
        </li>
        <li>
          <span style="margin-right: 5%;color: azure;"> Cold brew </span>
          <button class="lgn" onclick="addToCart('Hot Coffee', 'Cold brew')"> + </button>
          <span style="border: 1px solid black; padding: 0.3%; margin:1%;color: azure;" id="count5">0</span>
          <span style="margin-left:0.5% ;" id="c5"> </span> <span>$</span>
        </li>
        <li>
          <span style="margin-right: 1.8%;color: azure;"> Irish Coffee </span>
          <button class="lgn" onclick="addToCart('Hot Coffee', 'Irish coffee')"> + </button>
          <span style="border: 1px solid black; padding: 0.3%; margin:1%;color: azure;" id="count6">0</span>
          <span style="margin-left:0.5% ;" id="c6"> </span> <span>$</span>
        </li>
      </ul>

      </div>

      <div style="width: 25%;">

        <h3 class="hover-text"onclick="toggleSubtypes(2)">Cold Coffee</h3>
        <ul id="subtype-list-2" class="subtype-list">
          <li>
            <span style="margin-right: 1.8%;color: azure;"> Nitro Coffee </span>
            <button class="lgn" onclick="addToCart('Cold coffee', 'Nitro coffee')">  +  </button>
            <span style="border: 1px solid black; padding: 0.3%; margin:1%;color: azure;" id="count7">0</span>
            <span style="margin-left:0.5% ;" id="c7"> </span> <span>$</span>
          </li>
          <li>
            <span style="margin-right: 2%;color: azure;"> Frappuccino </span>
            <button class="lgn" onclick="addToCart('Cold coffee', 'Frappuccino')"> + </button>
            <span style="border: 1px solid black; padding: 0.3%; margin:1%;color: azure;" id="count8">0</span>
            <span style="margin-left:0.5% ;" id="c8"> </span> <span>$</span>
          </li>
        </ul>
      </div>

      <div style="width: 25%;">

        <h3 class="hover-text" onclick="toggleSubtypes(3)">Donuts</h3>
        <ul id="subtype-list-3" class="subtype-list">
          <li>
            <span style="margin-right: 2%;color: azure;"> Chocolate </span>
            <button class="lgn" onclick="addToCart('Donuts', 'Chocolate')"> + </button>
            <span style="border: 1px solid black; padding: 0.3%; margin:1%;" id="count9">0</span>
            <span style="margin-left:0.5% ;" id="c9"> </span> <span>$</span>
          </li>
          <li>
            <span style="margin-right: 2%;color: azure;"> Strawbery </span>
            <button class="lgn" onclick="addToCart('Donuts', 'Strawbery')"> + </button>
            <span style="border: 1px solid black; padding: 0.3%; margin:1%;" id="count10">0</span>
            <span style="margin-left:0.5% ;" id="c10"> </span> <span>$</span>
          </li>
          <li>
            <span style="margin-right: 11%; color: azure;" > Vanila </span>
            <button class="lgn" onclick="addToCart('Donuts', 'Vanila')"> + </button>
            <span style="border: 1px solid black; padding: 0.3%; margin:1%;" id="count11">0</span>
            <span style="margin-left:0.5% ;" id="c11"> </span> <span>$</span>
          </li>
          <li>
            <span style="margin-right: 6%;color: azure;"> Brownie </span>
            <button class="lgn" onclick="addToCart('Donuts', 'Brownie')"> + </button>
            <span style="border: 1px solid black; padding: 0.3%; margin:1%; ;" id="count12">0</span>
            <span style="margin-left:0.5% ;" id="c12"> </span> <span>$</span>
          </li>
        </ul>
      </div>
    </div>
  </div>
  
  <div id="cartItems" class="con"></div>
    <div id="totalBill" class="con"></div>
  <button ><a href="complete.php">OK</a></button>
<script>
   updateCart(); // Initial update of the cart
</script>

 
</body>
</html>
