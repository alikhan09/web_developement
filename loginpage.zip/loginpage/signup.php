<?php
   $name = $_POST['username'];
    $email = $_POST['email'];
     $pass = $_POST['pass'];

       $conn = new mysqli("localhost","root","", "loginpage");
       //insert querry
    $q ="insert into user_info (username,email,password) values('".$name."','".$email."',".$pass.")";
     
       if ($conn->query($q) === TRUE) {
        echo "successfully signed up !!!!!";
         header ("Location:index.php");
         } else {
         echo "Error deleting record: " . $conn->error;
         }
    
?>