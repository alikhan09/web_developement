<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>login page</title>
</head>
<body>
    <div>
        <h1> Enter Data to sign up </h1>
        <form action="signup.php" method="POST">
		<input type="text" name="username" placeholder="Enter username"> <br>
		<input type="email" name="email" placeholder="Enter email"><br>
		<input type="password" name="pass" placeholder="Enter Password"><br>
		<input type="submit" value="SignUp">
	</form>
       
    </div>
    <div>
        <h1>Click here to login </h1>
    <a href="login.php"> Login <br></a>
    </div>

   
</body>
</html>