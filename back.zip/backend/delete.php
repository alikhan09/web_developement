<?php
$id = $_GET['id'];
       $conn = new mysqli("localhost","root","", "ali");

       
//delete querry
$sql = "DELETE FROM std_info WHERE std_id=".$id."";
if ($conn->query($sql) === TRUE) {
header ("Location:index.php");
} else {
echo "Error deleting record: " . $conn->error;
}
?>