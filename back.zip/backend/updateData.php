<?php
   $name = $_POST['std_name'];
    $email = $_POST['std_email'];
     $age = $_POST['std_age'];
     $conn = new mysqli("localhost","root","", "ali");
     //update querry
       $sql1 = "UPDATE std_info SET std_email='".$email."'";
       $sql2 = "UPDATE std_info SET std_name='".$name."'";
       $sql3 = "UPDATE std_info SET std_age=".$age." ";

if ($conn->query($sql1) === TRUE && $conn->query($sql2) === TRUE  && $conn->query($sql3) === TRUE) {
    header ("Location:index.php");
} else {
  echo "Error updating record: " . $conn->error;
}
?>