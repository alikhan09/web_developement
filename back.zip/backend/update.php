<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<?php
$id = $_GET['id'];
   $conn = new mysqli("localhost","root","", "ali");
   $q="select* from std_info where std_id =".$id."";
   $sd = $conn->query($q);
   $row = $sd->fetch_assoc();

?>
	<form action="updateData.php" method="POST">
		<input type="text" name="std_name" value ="<?php echo $row['std_name']; ?>" > <br>
		<input type="text" name="std_email" value ="<?php echo $row['std_email']; ?>" ><br>
		<input type="int" name="std_age" value ="<?php echo $row['std_age']; ?>" ><br>
		<input type="submit" value="save my data">
	</form>
</body>
</html>