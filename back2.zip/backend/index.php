<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<form action="insert.php" method="POST">
		<input type="text" name="std_name" placeholder="Enter name"> <br>
		<input type="text" name="std_email" placeholder="Enter email"><br>
		<input type="int" name="std_age" placeholder="Enter age"><br>
		<input type="submit" value="save my data">
	</form>
<?php
	$conn = new mysqli("localhost","root","", "ali");
       $q="select* from std_info";
       $sd = $conn->query($q);
       echo "<table border=2px solid black >";
    echo "<tr>";
    echo "<th>";
    echo "std_id";
    echo "</th>";
    
    echo "<th>";
    echo "std_name";
    echo "</th>";
    
    echo "<th>";
    echo "std_email";
    echo "</th>";
    
    echo "<th>";
    echo "std_age";
    echo "</th>";
    
    echo "</tr>";
    
    while($row = $sd->fetch_assoc())
    {
      echo "<tr>";
      echo "<td>";
      echo $row["std_id"];
      echo "</td>";
      
      echo "<td>";
      echo $row["std_name"];
      echo "</td>";
      
      echo "<td>";
      echo $row["std_email"];
      echo "</td>";
      
      echo "<td>";
      echo $row["std_age"];
      echo "</td>";
      
	  echo "<td>";
      echo "<a href = 'delete.php?id=".$row["std_id"]."' >";
	  echo "delete";
	  echo "</a>";
      echo "</td>";

	  echo "<td>";
      echo "<a href = 'update.php?id=".$row["std_id"]."' >";
	  echo "Update";
	  echo "</a>";
      echo "</td>";

      echo "</tr>";
    }
       echo "</table>";

?>
</body>
</html>